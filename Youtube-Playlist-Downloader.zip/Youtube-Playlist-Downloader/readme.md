get your cookies from a browser extension and place it in this directory and call it "cookies.txt"

